<?php
function local_microcapsulas_extend_navigation(global_navigation $root)
{
    global $PAGE, $USER, $CFG;

    // 1) Si está dentro de un curso → no mostrar
    if (!empty($PAGE->course->id) && $PAGE->course->id != SITEID) {
        return;
    }

    // 2) Verificar si el usuario es estudiante (roleid = 5)
    $roles = get_user_roles(context_system::instance(), $USER->id);
    $isstudent = false;

    foreach ($roles as $r) {
        if ($r->roleid == 5) { // Estudiante
            $isstudent = true;
            break;
        }
    }

    if (!$isstudent) {
        return;
    }

    // 3) Verificar si el estudiante tiene cursos visibles en categoría 4
    require_once($CFG->dirroot . '/course/lib.php');

    $courses = enrol_get_users_courses($USER->id, true); // solo cursos visibles

    $hasvisiblecategory4 = false;

    foreach ($courses as $c) {
        if ($c->category == 4 && $c->visible == 1) {
            $hasvisiblecategory4 = true;
            break;
        }
    }

    if (!$hasvisiblecategory4) {
        return;
    }

    // 4) Construir la URL del módulo
    $main_url = new moodle_url(
        '/../lmsActividades/config/login_config.php',
        ['user' => $USER->id, 'sesskey' => sesskey()]
    );

    $mynode = navigation_node::create(
        get_string('pluginname', 'local_microcapsulas'),
        $main_url,
        navigation_node::TYPE_CUSTOM,
        null,
        'local_microcapsulas_global',
        new pix_icon('i/grades', '')
    );
    $mynode->showinflatnavigation = true;

    // 5) Colocar el nodo debajo de “Mis cursos”
    $mycoursesnode = null;

    foreach ($root->children as $key => $child) {
        $text = is_string($child->text) ? $child->text : $child->text->out();
        if (trim($text) === "Mis cursos") {
            $mycoursesnode = $child;
            break;
        }
    }

    if ($mycoursesnode) {
        $parent = $mycoursesnode->parent ?: $root;
        $parent->add_node($mynode, $mycoursesnode->key + 1);
    } else {
        // fallback
        $root->add_node($mynode);
    }
}
